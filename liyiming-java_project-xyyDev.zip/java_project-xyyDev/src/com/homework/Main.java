package com.homework;
public class Main {

    public static void main(String[] args) {
        com.homework.lym.Main.main(args);
	// write your code here
    }
}
